import mysql.connector

def conectar_bd():
    return mysql.connector.connect(
        host='localhost',
        port=3305,
        user='root',
        password='12345',
        database='infnet'
    )

def criar_funcionario(conn):
    nome = input("Digite o nome do funcionário: ")
    sobrenome = input("Digite o sobrenome do funcionário: ")
    idade = int(input("Digite a idade do funcionário: "))
    setor = input("Digite o nome do setor do funcionário: ")

    cursor = conn.cursor()
    cursor.execute("SELECT * FROM setor WHERE nome_setor = %s", (setor,))
    resultado_setor = cursor.fetchone()

    if resultado_setor:
        nome_funcionario = resultado_setor[1]
        nome_funcionario += f",{nome}" 
        cursor.execute("UPDATE setor SET nome_funcionario = %s WHERE nome_setor = %s", (nome_funcionario, setor))
        conn.commit()
    else:
        cursor.execute("INSERT INTO setor (nome_setor, nome_funcionario) VALUES (%s, %s)", (setor, nome))
        conn.commit()

    cursor.execute("INSERT INTO funcionario (nome, sobrenome, idade, setor) VALUES (%s, %s, %s, %s)",
                   (nome, sobrenome, idade, setor))
    conn.commit()
    print("Funcionário criado com sucesso!")

def menu():
    print("\n--- Menu ---")
    print("[1] Criar Funcionário")
    print("[2] Consultar Funcionário")
    print("[3] Atualizar Funcionário")
    print("[4] Deletar Funcionário")
    print("[5] Consultar todos os funcionários")
    print("[6] Consultar funcionários por setor")
    print("[7] Exibir todos os setores e funcionários")
    print("[8] Sair")

def consultar_funcionario(conn):
    nome_funcionario = input("Digite o nome do funcionário que deseja consultar: ")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM funcionario WHERE nome = %s", (nome_funcionario,))
    funcionario = cursor.fetchone()
    if funcionario:
        print("ID:", funcionario[0])
        print("Nome:", funcionario[1])
        print("Sobrenome:", funcionario[2])
        print("Idade:", funcionario[3])
        print("")
    else:
        print("Funcionário não encontrado.")
        print("")

def consultar_setor(conn):
    nome_setor = input("Digite o nome do setor que deseja consultar: ")
    cursor = conn.cursor()
    cursor.execute("SELECT f.*, s.nome_funcionario FROM funcionario f JOIN setor s ON f.setor = s.nome_setor WHERE s.nome_setor = %s", (nome_setor,))
    
    funcionarios = cursor.fetchall()
    if funcionarios:
        for funcionario in funcionarios:
            print("ID:", funcionario[0])
            print("Nome:", funcionario[1])
            print("Sobrenome:", funcionario[2])
            print("Idade:", funcionario[3])
            print("Setor:", nome_setor)
            print("Funcionários:", funcionario[4])
    else:
        print("Nenhum funcionário encontrado para o setor informado.")

def consultar_todos(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM funcionario")
    funcionarios = cursor.fetchall()
    if funcionarios:
        for funcionario in funcionarios:
            print("ID:", funcionario[0])
            print("Nome:", funcionario[1])
            print("Sobrenome:", funcionario[2])
            print("Idade:", funcionario[3])
            print("Setor:", funcionario[4])
    else:
        print("Nenhum funcionário cadastrado.")

def atualizar_funcionario(conn):
    nome = input("Digite o nome do funcionário que deseja atualizar: ")
    sobrenome = input("Digite o sobrenome do funcionário que deseja atualizar: ")
    novo_nome = input("Digite o novo nome: ")
    novo_sobrenome = input("Digite o novo sobrenome: ")
    nova_idade = int(input("Digite a nova idade: "))
    novo_setor = input("Digite o novo setor: ")

    cursor = conn.cursor()
    cursor.execute("UPDATE funcionario SET nome = %s, sobrenome = %s, idade = %s, setor = %s WHERE nome = %s AND sobrenome = %s",
                   (novo_nome, novo_sobrenome, nova_idade, novo_setor, nome, sobrenome))
    conn.commit()
    print("Funcionário atualizado com sucesso!")

def deletar_funcionario(conn):
    nome = input("Digite o nome do funcionário que deseja deletar: ")
    sobrenome = input("Digite o sobrenome do funcionário que deseja deletar: ")

    cursor = conn.cursor()
    cursor.execute("DELETE FROM funcionario WHERE nome = %s AND sobrenome = %s", (nome, sobrenome))
    conn.commit()
    print("Funcionário deletado com sucesso!")

def setores_funcionarios(conn):
    cursor = conn.cursor()
    cursor.execute("SELECT s.nome_setor, s.nome_funcionario FROM setor s")
    setores = cursor.fetchall()

    if setores:
        for setor in setores:
            nome_setor = setor[0]
            funcionarios = setor[1].split(",") if setor[1] else []
            
            print("Setor:", nome_setor)
            if funcionarios:
                for funcionario in funcionarios:
                    print("  - Funcionário:", funcionario)
            else:
                print("  - Nenhum funcionário neste setor")
            print("") 
    else:
        print("Nenhum setor encontrado.")

def main():
    conn = conectar_bd()
    try:
        while True:
            menu()
            escolha = input("Escolha uma opção: ")
            if escolha == "1":
                criar_funcionario(conn)
            elif escolha == "2":
                consultar_funcionario(conn)
            elif escolha == "3":
                atualizar_funcionario(conn)
            elif escolha == "4":
                deletar_funcionario(conn)
            elif escolha == "5":
                consultar_todos(conn)
            elif escolha == "6":
                consultar_setor(conn)
            elif escolha == "7":
                consultar_setor(conn)
            elif escolha == "8":
                conn.close()
                print("Programa encerrado.")
                break
            else:
                print("Opção inválida. Tente novamente.")
    finally:
        conn.close()

if __name__ == "__main__":
    main()