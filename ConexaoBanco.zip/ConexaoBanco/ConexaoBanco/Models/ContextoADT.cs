﻿using ConexaoBanco.Controllers;
using Microsoft.EntityFrameworkCore;

namespace ConexaoBanco.Models {
    public class ContextoADT : DbContext {
        public ContextoADT(DbContextOptions<ContextoADT> options) : base(options) {

        }
        public DbSet<ADT> ADT { get; set; }
    }
}