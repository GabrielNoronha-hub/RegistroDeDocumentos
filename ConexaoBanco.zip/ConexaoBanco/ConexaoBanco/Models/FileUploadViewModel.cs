﻿using Microsoft.AspNetCore.Http;

namespace ConexaoBanco.Models
{
    public class FileUploadViewModel
    {
        public IFormFile File { get; set; }
    }
}