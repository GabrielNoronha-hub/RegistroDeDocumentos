﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConexaoBanco.Models {
    [Table("Arquivo")]
    public class Arquivo {
        [Column("Id")]
        [Display(Name = "Código")]
        public int Id { get; set; }

        [Column("ArquivoName")]
        [Display(Name = "ArquivoName")]
        public string ArquivoName { get; set; }

        [Column("ArquivoPath")]
        [Display(Name = "ArquivoPath")]
        public string ArquivoPath { get; set; }

    }
}
