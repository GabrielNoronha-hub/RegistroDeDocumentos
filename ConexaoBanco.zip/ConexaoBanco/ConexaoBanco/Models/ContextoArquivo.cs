﻿using ConexaoBanco.Controllers;
using Microsoft.EntityFrameworkCore;

namespace ConexaoBanco.Models {
    public class ContextoArquivo : DbContext {
        public ContextoArquivo(DbContextOptions<ContextoArquivo> options) : base(options) {

        }
        public DbSet<Arquivo> Arquivo { get; set; }
        public int Id { get; set; }
        public string ArquivoName { get; set; }
        public string ArquivoPath { get; set; }
    }
}
