﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConexaoBanco.Models
{
    [Table("OC")]
    public class OC
    {
        [Column("Id")]
        [Display(Name = "Código")]
        public int Id { get; set; }

        [Column("Tipo")]
        [Display(Name = "Tipo")]
        public string Tipo { get; set; }

        [Column("Data_Assinatura")]
        [Display(Name = "Data de Assinatura")]
        public DateTime? Data_Assinatura { get; set; }

        [Column("Documento")]
        [Display(Name = "Documento")]
        public string Documento { get; set; }

        [Column("Fornecedor")]
        [Display(Name = "Fornecedor")]
        public string Fornecedor { get; set; }

        [Column("Projeto")]
        [Display(Name = "Projeto")]
        public string Projeto { get; set; }

        [Column("Data_Vencimento")]
        [Display(Name = "Data de Vencimento")]
        public DateTime? Data_Vencimento { get; set; }

        [Column("Valor_Reais")]
        [Display(Name = "Valor em Reais")]
        public decimal? Valor_Reais { get; set; }

        [Column("Valor_Dolar")]
        [Display(Name = "Valor em Dolar")]
        public decimal? Valor_Dolar { get; set; }

        [Column("Valor_Euro")]
        [Display(Name = "Valor em Euro")]
        public decimal? Valor_Euro { get; set; }

        [Column("Competencia")]
        [Display(Name = "Competência")]
        public string Competencia { get; set; }

        [Column("Observacoes")]
        [Display(Name = "Observações")]
        public string Observacoes { get; set; }

        [Column("Responsavel")]
        [Display(Name = "Responsável")]
        public string Responsavel { get; set; }

        [Column("Controle_Especial")]
        [Display(Name = "Controle Especial")]
        public string Controle_Especial { get; set; }

        [Column("Recorrente")]
        [Display(Name = "Recorrente")]
        public string Recorrente { get; set; }

        [Column("Planilhado")]
        [Display(Name = "Planilhado")]
        public DateTime? Planilhado { get; set; }

        [Column("Justificativa")]
        [Display(Name = "Justificativa")]
        public string Justificativa { get; set; }

        [Column("Aprovador")]
        [Display(Name = "Aprovador")]
        public bool Aprovador { get; set; }

    }
}