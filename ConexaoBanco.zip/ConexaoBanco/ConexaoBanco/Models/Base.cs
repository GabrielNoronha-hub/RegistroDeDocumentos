﻿using Microsoft.AspNetCore.Components.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ConexaoBanco.Models
{
    [Table("Base")]
    public class Base
    {
        [Column("Id")]
        [Display(Name = "Id")]
        public int Id { get; set; }

        [Column("Nº_interno")]
        [Display(Name = "Nº_interno")]
        public int Nº_interno { get; set; }

        [Column("Data_do_documento")]
        [Display(Name = "Data_do_documento")]
        public DateTime? Data_do_documento { get; set; }

        [Column("Status_do_depósito")]
        [Display(Name = "Status_do_depósito")]
        public string Status_do_depósito { get; set; }

        [Column("STATUS")]
        [Display(Name = "STATUS")]
        public string STATUS { get; set; }

        [Column("Código_do_cliente_fornecedor")]
        [Display(Name = "Código_do_cliente_fornecedor")]
        public string Código_do_cliente_fornecedor { get; set; }

        [Column("Nome_do_cliente_fornecedor")]
        [Display(Name = "Nome_do_cliente_fornecedor")]
        public string Nome_do_cliente_fornecedor { get; set; }

        [Column("Total_do_documento")]
        [Display(Name = "Total_do_documento")]
        public float Total_do_documento { get; set; }

        [Column("Nº_de_série")]
        [Display(Name = "Nº_de_série")]
        public int Nº_de_série { get; set; }

        [Column("Obs_Nota")]
        [Display(Name = "Obs_Nota")]
        public string Obs_Nota { get; set; }

        [Column("Nº_da_linha")]
        [Display(Name = "Nº_da_linha")]
        public string Nº_da_linha { get; set; }

        [Column("Quantidade")]
        [Display(Name = "Quantidade")]
        public string Quantidade { get; set; }

        [Column("Preço")]
        [Display(Name = "Preço")]
        public float Preço { get; set; }

        [Column("Total_da_linha")]
        [Display(Name = "Total_da_linha")]
        public float Total_da_linha { get; set; }

        [Column("Nº_do_item")]
        [Display(Name = "Nº_do_item")]
        public string Nº_do_item { get; set; }

        [Column("Descrição_do_item_serviço")]
        [Display(Name = "Descrição_do_item_serviço")]
        public string Descrição_do_item_serviço { get; set; }

        [Column("Regra_distribuição")]
        [Display(Name = "Regra_distribuição")]
        public int Regra_distribuição { get; set; }

        [Column("Nome_do_centro")]
        [Display(Name = "Nome_do_centro")]
        public string Nome_do_centro { get; set; }

        [Column("Projeto")]
        [Display(Name = "Projeto")]
        public string Projeto { get; set; }

        [Column("Nome_projeto")]
        [Display(Name = "Nome_projeto")]
        public string Nome_projeto { get; set; }

        [Column("Designação_Telespazio")]
        [Display(Name = "Designação_Telespazio")]
        public string Designação_Telespazio { get; set; }

        [Column("Código_da_conta")]
        [Display(Name = "Código_da_conta")]
        public int Código_da_conta { get; set; }

        [Column("Referência_do_documento_base")]
        [Display(Name = "Referência_do_documento_base")]
        public string Referência_do_documento_base { get; set; }

        [Column("Nome_da_conta")]
        [Display(Name = "Nome_da_conta")]
        public string Nome_da_conta { get; set; }

        [Column("ID_0_impos")]
        [Display(Name = "ID_0_impos")]
        public string ID_0_impos { get; set; }

        [Column("N1")]
        [Display(Name = "N1")]
        public string N1 { get; set; }

        [Column("N2")]
        [Display(Name = "N2")]
        public string N2 { get; set; }

        [Column("N3")]
        [Display(Name = "N3")]
        public string N3 { get; set; }

        [Column("Linha_da_data_de_entrega")]
        [Display(Name = "Linha_da_data_de_entrega")]
        public DateTime Linha_da_data_de_entrega { get; set; }

        [Column("Mês_Competência")]
        [Display(Name = "Mês_Competência")]
        public int Mês_Competência { get; set; }

        [Column("Ano_Competência")]
        [Display(Name = "Ano_Competência")]
        public int Ano_Competência { get; set; }

        [Column("Regiões")]
        [Display(Name = "Regiões")]
        public string Regiões { get; set; }

    }
}