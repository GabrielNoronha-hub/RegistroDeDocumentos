﻿using Microsoft.EntityFrameworkCore;

namespace ConexaoBanco.Models
{
    public class ContextoAPF : DbContext
    {
        public ContextoAPF(DbContextOptions<ContextoAPF> options) : base(options)
        {

        }

        public DbSet<APF> APF { get; set; }

    }
}
