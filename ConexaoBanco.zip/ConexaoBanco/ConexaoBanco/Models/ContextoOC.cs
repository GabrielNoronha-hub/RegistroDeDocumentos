﻿using Microsoft.EntityFrameworkCore;

namespace ConexaoBanco.Models
{
    public class ContextoOC: DbContext
    {
        public ContextoOC(DbContextOptions<ContextoOC> options) : base(options)
        {

        }

        public DbSet<OC> OC { get; set; }

    }
}
