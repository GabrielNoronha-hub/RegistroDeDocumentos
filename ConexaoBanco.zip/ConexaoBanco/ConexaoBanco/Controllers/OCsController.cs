﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ConexaoBanco.Models;
using Google.Protobuf.WellKnownTypes;

namespace ConexaoBanco.Controllers
{
    public class OCsController : Controller
    {
        private readonly ContextoOC _contextocs;

        public OCsController(ContextoOC contextocs)
        {
            _contextocs = contextocs;
        }

        // GET: Registros
        public async Task<IActionResult> Index()
        {
            return View(await _contextocs.OC.ToListAsync());
        }

        // GET: Registros/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oc = await _contextocs.OC
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oc == null)
            {
                return NotFound();
            }

            return View(oc);
        }

        // GET: Registros/Create
        public IActionResult CreateOC()
        {
            return View();
        }

        // POST: Registros/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateOC([Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador")] OC oc)
        {
            if (ModelState.IsValid)
            {
                _contextocs.Add(oc);
                await _contextocs.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(oc);
        }

        // GET: Registros/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oc = await _contextocs.OC.FindAsync(id);
            if (oc == null)
            {
                return NotFound();
            }
            return View("Edit", oc);
        }

        // POST: Registros/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador")] OC oc)
        {
            if (id != oc.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _contextocs.Update(oc);
                    await _contextocs.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!OCExists(oc.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(oc);
        }

        // GET: Registro/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var oc = await _contextocs.OC
                .FirstOrDefaultAsync(m => m.Id == id);
            if (oc == null)
            {
                return NotFound();
            }

            return View(oc);
        }

        // POST: Registro/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var oc = await _contextocs.OC.FindAsync(id);
            _contextocs.OC.Remove(oc);
            await _contextocs.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool OCExists(int id)
        {
            return _contextocs.OC.Any(e => e.Id == id);
        }
    }
}
