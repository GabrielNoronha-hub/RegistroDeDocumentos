﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ConexaoBanco.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Diagnostics;

namespace ConexaoBanco.Controllers
{
    public class HomeController : Controller
    {
        private readonly ContextoAPF _contextapfs;
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger, ContextoAPF contextapfs)
        {
            _logger = logger;
            _contextapfs = contextapfs;
        }

        public IActionResult Index()
        {
            var apfList = _contextapfs.APF.ToList();
            return View(apfList);
        }

        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apf = await _contextapfs.APF.FindAsync(id);
            if (apf == null)
            {
                return NotFound();
            }

            return View("Edit", apf);
        }

        // GET: Registros/EditWithCurrentData/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador")] APF apf)
        {
            if (id != apf.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _contextapfs.Update(apf);
                    await _contextapfs.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!APFExists(apf.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            return View("Edit", apf);
        }

        private bool APFExists(int id)
        {
            return _contextapfs.APF.Any(e => e.Id == id);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}