﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ConexaoBanco.Models;

namespace ConexaoBanco.Controllers
{
    public class ADTsController : Controller
    {
        private readonly ContextoADT _contextadts;

        public ADTsController(ContextoADT contextadts)
        {
            _contextadts = contextadts;
        }

        // GET: Registros
        public async Task<IActionResult> Index()
        {
            return View(await _contextadts.ADT.ToListAsync());
        }

        // GET: Registros/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var adt = await _contextadts.ADT
                .FirstOrDefaultAsync(m => m.Id == id);
            if (adt == null)
            {
                return NotFound();
            }

            return View(adt);
        }

        // GET: Registros/Create
        public IActionResult CreateADT(int arquivoId) {
            ViewBag.ArquivoId = arquivoId;
            return View();
        }

        // POST: Registros/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateADT([Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador, ArquivoId")] ADT adt) {
            if (ModelState.IsValid) {
                _contextadts.Add(adt);
                await _contextadts.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(adt);
        }

        // GET: Registros/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var adt = await _contextadts.ADT.FindAsync(id);
            if (adt == null)
            {
                return NotFound();
            }
            return View(adt);
        }

        // POST: Registros/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador")] ADT adt)
        {
            if (id != adt.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _contextadts.Update(adt);
                    await _contextadts.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ADTExists(adt.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(adt);
        }

        // GET: Registro/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var adt = await _contextadts.ADT
                .FirstOrDefaultAsync(m => m.Id == id);
            if (adt == null)
            {
                return NotFound();
            }

            return View(adt);
        }

        // POST: Registro/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var adt = await _contextadts.ADT.FindAsync(id);
            _contextadts.ADT.Remove(adt);
            await _contextadts.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ADTExists(int id)
        {
            return _contextadts.ADT.Any(e => e.Id == id);
        }
    }
}
