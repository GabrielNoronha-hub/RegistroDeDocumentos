﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using ConexaoBanco.Models;
using Google.Protobuf.WellKnownTypes;
using Microsoft.EntityFrameworkCore;

namespace ConexaoBanco.Controllers {
    public class FileUploadController : Controller {
        private readonly IConfiguration _configuration;
        private readonly ContextoArquivo _contextarquivo;

        public FileUploadController(ContextoArquivo contextarquivo) {
            _contextarquivo = contextarquivo;
        }

        // GET: Registros
        public async Task<IActionResult> Index() {
            return View(await _contextarquivo.Arquivo.ToListAsync());
        }

        public FileUploadController(IConfiguration configuration) {
        _configuration = configuration;
        }

        public IActionResult In() {
            return View();
        }

        // GET: Registros/Create
        public IActionResult UploadFile(int Id) {
            ViewBag.ArquivoId = Id;
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadFile(FileUploadViewModel model) {
            if (ModelState.IsValid) {
                string filename = Path.GetFileName(model.File.FileName);
                string arquivoPath = Path.Combine("uploads", filename);

                string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                string fullArquivoPath = Path.Combine(uploadsFolder, filename);

                using (var stream = new FileStream(fullArquivoPath, FileMode.Create)) {
                    await model.File.CopyToAsync(stream);
                }

                string connectionString = "Server=localhost;Port=3305;Database=assinadorTpz;User=root;Password=12345";
                using (MySqlConnection con = new MySqlConnection(connectionString)) // Use MySqlConnection em vez de SqlConnection
                {
                    await con.OpenAsync();
                    using (MySqlCommand cmd = new MySqlCommand("INSERT INTO Arquivo (ArquivoName, ArquivoPath) VALUES (@ArquivoName, @ArquivoPath)", con)) // Use MySqlCommand em vez de SqlCommand
                    {
                        cmd.Parameters.AddWithValue("@ArquivoName", filename);
                        cmd.Parameters.AddWithValue("@ArquivoPath", arquivoPath);
                        await cmd.ExecuteNonQueryAsync();
                    }
                }

                return View();
            }

            return View("Error");
        }
    }
}