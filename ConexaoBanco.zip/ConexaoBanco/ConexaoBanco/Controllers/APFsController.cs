﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using ConexaoBanco.Models;

namespace ConexaoBanco.Controllers
{
    public class APFsController : Controller
    {
        private readonly ContextoAPF _contextapfs;

        public APFsController(ContextoAPF contextapfs)
        {
            _contextapfs = contextapfs;
        }

        // GET: Registros
        public async Task<IActionResult> Index()
        {
            return View(await _contextapfs.APF.ToListAsync());
        }

        // GET: Registros/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apf = await _contextapfs.APF
                .FirstOrDefaultAsync(m => m.Id == id);
            if (apf == null)
            {
                return NotFound();
            }

            return View(apf);
        }

        // GET: Registros/Create
        public IActionResult CreateAPF()
        {
            return View();
        }

        // POST: Registros/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateAPF([Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador")] APF apf)
        {
            if (ModelState.IsValid)
            {
                _contextapfs.Add(apf);
                await _contextapfs.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(apf);
        }

        // GET: Registros/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apf = await _contextapfs.APF.FindAsync(id);
            if (apf == null)
            {
                return NotFound();
            }

            return View("Edit", apf);
        }

        // GET: Registros/EditWithCurrentData/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id, Tipo, Data_Assinatura, Documento, Fornecedor, Projeto, Data_Vencimento, Valor_Reais, Valor_Dolar, Valor_Euro, Competencia, Observacoes, Responsavel, Controle_Especial, Recorrente, Planilhado, Justificativa, Aprovador")] APF apf)
        {
            if (id != apf.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _contextapfs.Update(apf);
                    await _contextapfs.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!APFExists(apf.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            return View("Edit", apf);
        }

        // GET: Registro/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var apf = await _contextapfs.APF
                .FirstOrDefaultAsync(m => m.Id == id);
            if (apf == null)
            {
                return NotFound();
            }

            return View(apf);
        }

        // POST: Registro/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var apf = await _contextapfs.APF.FindAsync(id);
            _contextapfs.APF.Remove(apf);
            await _contextapfs.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool APFExists(int id)
        {
            return _contextapfs.APF.Any(e => e.Id == id);
        }
    }
}
